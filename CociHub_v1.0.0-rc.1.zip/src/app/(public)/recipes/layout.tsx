import type {
  ReactNode,
} from "react";

import {
  createStaticPageMetadata,
} from "@/lib/seo/create-static-page-metadata";


export const metadata =
  createStaticPageMetadata({
    title:
      "Recetas",

    description:
      "Explora las recetas publicadas en CociHub y encuentra nuevas ideas para cocinar.",

    path:
      "/recipes",
  });


type RecipesLayoutProps = {
  children:
    ReactNode;
};


export default function RecipesLayout({
  children,
}: RecipesLayoutProps) {
  return children;
}